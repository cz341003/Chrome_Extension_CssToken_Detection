export default defineBackground(() => {
  console.log('CSS Token Detector Background Loaded');

  // 点击图标时打开侧边栏
  browser.action.onClicked.addListener(async (tab) => {
    if (tab.id) {
      await browser.sidePanel.open({ tabId: tab.id });
    }
  });

  // 监听标签页更新（如路由变化、刷新）
  browser.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === 'complete' && tab.active) {
      browser.runtime.sendMessage({ type: 'TAB_UPDATED', tabId }).catch(() => {
        // 忽略侧边栏未打开时的错误
      });
    }
  });

  // 监听标签页切换
  browser.tabs.onActivated.addListener((activeInfo) => {
    browser.runtime.sendMessage({ type: 'TAB_ACTIVATED', tabId: activeInfo.tabId }).catch(() => {
      // 忽略侧边栏未打开时的错误
    });
  });
});
